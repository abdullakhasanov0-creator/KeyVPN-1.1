package com.keyvpn.app.data

import com.keyvpn.app.AppScope
import com.keyvpn.app.core.ConfigBuilder
import com.keyvpn.app.core.Json
import com.keyvpn.app.core.Server
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull
import libv2ray.Libv2ray
import java.util.concurrent.atomic.AtomicInteger

/** Автотест: реальный пинг через ядро Xray (полный handshake до сервера + запрос generate_204). */
object PingTester {
    private const val TIMEOUT_MS = 9_000L
    private const val PARALLEL = 8
    private const val FRESH_MS = 3 * 60_000L

    private val mutex = Mutex()

    /** (проверено, всего) пока идёт тест, иначе null. */
    val progress = MutableStateFlow<Pair<Int, Int>?>(null)

    suspend fun testAll(list: List<Server>) {
        if (list.isEmpty()) return
        mutex.withLock {
            val total = list.size
            val done = AtomicInteger(0)
            progress.value = 0 to total
            try {
                coroutineScope {
                    val sem = Semaphore(PARALLEL)
                    list.map { s ->
                        launch(Dispatchers.IO) {
                            sem.withPermit {
                                Store.setPing(s.id, measure(s))
                                progress.value = done.incrementAndGet() to total
                            }
                        }
                    }.joinAll()
                }
            } finally {
                progress.value = null
            }
        }
    }

    /** Реальный пинг в мс; -1 если сервер не отвечает. */
    suspend fun measure(s: Server): Int {
        val job = AppScope.scope.async(Dispatchers.IO) {
            try {
                val cfg = ConfigBuilder.probe(Json.parseObject(s.outboundJson))
                Libv2ray.measureOutboundDelay(cfg, Settings.testUrl)
            } catch (e: Throwable) {
                -1L
            }
        }
        val r = withTimeoutOrNull(TIMEOUT_MS) { job.await() } ?: -1L
        return if (r > 0) r.toInt() else -1
    }

    /** Лучший (минимальный пинг) сервер. Если результаты старше 3 минут — сначала перетестирует. */
    suspend fun best(exclude: Set<String> = emptySet(), forceRetest: Boolean = false): Server? {
        val candidates = Store.servers.value.filter { it.id !in exclude }
        val now = System.currentTimeMillis()
        if (forceRetest || candidates.any { now - it.testedAt > FRESH_MS }) testAll(candidates)
        return Store.servers.value.filter { it.id !in exclude && it.pingMs > 0 }.minByOrNull { it.pingMs }
    }
}
