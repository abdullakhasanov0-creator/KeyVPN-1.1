package com.keyvpn.app

import android.app.Application
import android.util.Base64
import com.keyvpn.app.data.Importer
import com.keyvpn.app.data.PingTester
import com.keyvpn.app.data.Settings
import com.keyvpn.app.data.Store
import com.keyvpn.app.vpn.Phase
import com.keyvpn.app.vpn.VpnState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import libv2ray.Libv2ray
import java.security.SecureRandom

object AppScope {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
}

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Settings.init(this)
        initCore()
        // Автообновление подписок + автотест пинга при запуске
        AppScope.scope.launch {
            if (Settings.autoUpdate.value) Importer.refreshStale(6 * 3600_000L)
            if (VpnState.ui.value.phase != Phase.CONNECTED) PingTester.testAll(Store.servers.value)
        }
    }

    private fun initCore() {
        try {
            val prefs = getSharedPreferences("keyvpn_core", MODE_PRIVATE)
            var key = prefs.getString("xudp", null)
            if (key == null) {
                val b = ByteArray(32).also { SecureRandom().nextBytes(it) }
                key = Base64.encodeToString(b, Base64.NO_PADDING or Base64.URL_SAFE or Base64.NO_WRAP)
                prefs.edit().putString("xudp", key).apply()
            }
            Libv2ray.initCoreEnv(filesDir.absolutePath, key)
        } catch (e: Throwable) {
            // ядро не загрузилось — UI покажет ошибку при подключении
        }
    }
}
