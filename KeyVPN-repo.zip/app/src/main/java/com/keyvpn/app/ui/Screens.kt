package com.keyvpn.app.ui

import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.keyvpn.app.AppScope
import com.keyvpn.app.core.Fmt
import com.keyvpn.app.core.Server
import com.keyvpn.app.data.Importer
import com.keyvpn.app.data.PingTester
import com.keyvpn.app.data.Settings
import com.keyvpn.app.data.Store
import com.keyvpn.app.vpn.KeyVpnService
import com.keyvpn.app.vpn.Phase
import com.keyvpn.app.vpn.VpnState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import libv2ray.Libv2ray

@Composable
fun KeyVpnApp(clipOffer: String?, onClipHandled: () -> Unit, toast: String?, onToastShown: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val servers by Store.servers.collectAsState()
    val ui by VpnState.ui.collectAsState()
    val auto by Settings.autoMode.collectAsState()
    val progress by PingTester.progress.collectAsState()
    var selectedId by remember { mutableStateOf(Settings.selectedId) }
    var settingsOpen by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    val snack = remember { SnackbarHostState() }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) pending?.invoke()
        pending = null
    }

    fun startVpn(id: String?) {
        val go = { KeyVpnService.start(ctx, id) }
        val prep = VpnService.prepare(ctx)
        if (prep != null) { pending = go; permLauncher.launch(prep) } else go()
    }

    fun toggle() {
        when {
            ui.phase == Phase.IDLE || ui.phase == Phase.ERROR -> when {
                servers.isEmpty() -> showAdd = true
                auto -> startVpn(null)
                else -> startVpn(selectedId?.takeIf { id -> servers.any { it.id == id } } ?: servers.first().id)
            }
            else -> KeyVpnService.stop(ctx)
        }
    }

    fun select(s: Server) {
        Settings.setAuto(false)
        selectedId = s.id
        Settings.selectedId = s.id
        if (ui.phase == Phase.CONNECTED || ui.phase == Phase.CONNECTING) startVpn(s.id)
    }

    fun setMode(autoMode: Boolean) {
        Settings.setAuto(autoMode)
        if (autoMode && (ui.phase == Phase.CONNECTED || ui.phase == Phase.CONNECTING)) startVpn(null)
    }

    LaunchedEffect(toast) {
        if (toast != null) { snack.showSnackbar(toast); onToastShown() }
    }
    LaunchedEffect(clipOffer) {
        if (clipOffer != null) {
            val r = snack.showSnackbar("Найден ключ в буфере обмена", actionLabel = "Добавить")
            val text = clipOffer
            onClipHandled()
            if (r == SnackbarResult.ActionPerformed) snack.showSnackbar(Importer.import(text).message)
        }
    }

    BackHandler(enabled = settingsOpen) { settingsOpen = false }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack, Modifier.navigationBarsPadding()) },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            if (settingsOpen) {
                SettingsScreen(onBack = { settingsOpen = false })
            } else {
                MainScreen(
                    servers = servers, ui = ui, auto = auto, progress = progress, selectedId = selectedId,
                    onToggle = ::toggle, onSelect = ::select, onMode = ::setMode,
                    onAdd = { showAdd = true }, onSettings = { settingsOpen = true },
                    onRetest = { AppScope.scope.launch { PingTester.testAll(Store.servers.value) } },
                    onDelete = { Store.removeServer(it.id) },
                )
            }
        }
    }

    if (showAdd) {
        AddKeyDialog(
            onDismiss = { showAdd = false },
            onSubmit = { text ->
                showAdd = false
                scope.launch { snack.showSnackbar(Importer.import(text).message) }
            },
        )
    }
}

// ---------------------------------------------------------------- главный экран

@Composable
private fun MainScreen(
    servers: List<Server>, ui: com.keyvpn.app.vpn.VpnUi, auto: Boolean, progress: Pair<Int, Int>?, selectedId: String?,
    onToggle: () -> Unit, onSelect: (Server) -> Unit, onMode: (Boolean) -> Unit,
    onAdd: () -> Unit, onSettings: () -> Unit, onRetest: () -> Unit, onDelete: (Server) -> Unit,
) {
    val sorted = remember(servers) {
        servers.sortedWith(
            compareBy<Server> { if (it.pingMs > 0) 0 else if (it.pingMs == 0) 1 else 2 }
                .thenBy { if (it.pingMs > 0) it.pingMs else 0 }
        )
    }
    val bestId = sorted.firstOrNull { it.pingMs > 0 }?.id
    val connected = Store.get(ui.serverId)
    val shownId = if (ui.phase == Phase.CONNECTED || ui.phase == Phase.CONNECTING) ui.serverId else if (auto) bestId else selectedId

    val elapsed by produceState(0L, ui.connectedAt, ui.phase) {
        while (true) {
            value = if (ui.phase == Phase.CONNECTED) (System.currentTimeMillis() - ui.connectedAt) / 1000 else 0
            delay(1000)
        }
    }

    val title = when {
        ui.phase == Phase.CONNECTED -> "Защищено"
        ui.phase == Phase.ERROR -> "Не удалось подключиться"
        progress != null -> "Тестирую серверы…"
        ui.phase == Phase.CONNECTING -> "Подключаюсь…"
        ui.phase == Phase.TESTING -> "Выбираю лучший сервер…"
        else -> "Отключено"
    }
    val subtitle = when {
        ui.phase == Phase.CONNECTED -> "${connected?.name ?: ""} · ${connected?.pingMs?.takeIf { it > 0 }?.let { "$it мс" } ?: "…"} · ${Fmt.duration(elapsed)}"
        ui.phase == Phase.ERROR -> ui.message
        progress != null -> "Проверено ${progress.first} из ${progress.second}"
        ui.phase == Phase.CONNECTING -> connected?.name.orEmpty()
        servers.isEmpty() -> "Добавьте ключ или ссылку подписки"
        auto -> "Нажмите — подключу к самому быстрому серверу"
        else -> "Нажмите, чтобы подключиться к «${Store.get(selectedId)?.name ?: sorted.first().name}»"
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 8.dp, 16.dp, 32.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("KeyVPN", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "Настройки") }
            }
            Spacer(Modifier.height(16.dp))
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                PowerButton(ui.phase, progress != null, onToggle)
                Spacer(Modifier.height(18.dp))
                Text(title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
                Text(
                    subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp),
                )
                if (progress != null) {
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { progress.first / progress.second.toFloat().coerceAtLeast(1f) },
                        modifier = Modifier.fillMaxWidth(0.6f),
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = auto, onClick = { onMode(true) }, label = { Text("⚡ Авто · лучший пинг") })
                FilterChip(selected = !auto, onClick = { onMode(false) }, label = { Text("Выбрать вручную") })
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Серверы (${servers.size})", fontWeight = FontWeight.SemiBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = onRetest, enabled = progress == null && servers.isNotEmpty()) {
                    Icon(Icons.Default.Refresh, contentDescription = "Проверить пинг")
                }
                IconButton(onClick = onAdd) { Icon(Icons.Default.Add, contentDescription = "Добавить ключ") }
            }
            Spacer(Modifier.height(4.dp))
        }

        if (servers.isEmpty()) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Пока нет серверов", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Вставьте ключ (vless, vmess, trojan, ss) или ссылку подписки — приложение само проверит пинг и выберет лучший сервер.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = onAdd) { Text("Добавить ключ") }
                    }
                }
            }
        } else {
            items(sorted, key = { it.id }) { s ->
                ServerRow(
                    s = s, selected = s.id == shownId, best = auto && s.id == bestId,
                    onClick = { onSelect(s) }, onDelete = { onDelete(s) },
                )
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun PowerButton(phase: Phase, testing: Boolean, onClick: () -> Unit) {
    val busy = testing || phase == Phase.CONNECTING || phase == Phase.TESTING
    val target = when {
        phase == Phase.CONNECTED -> Green
        busy -> Amber
        phase == Phase.ERROR -> Red
        else -> Gray
    }
    val color by animateColorAsState(target, tween(400), label = "color")
    val spin = rememberInfiniteTransition(label = "spin")
    val angle by spin.animateFloat(0f, 360f, infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart), label = "angle")

    Box(
        Modifier.size(190.dp).clip(CircleShape).background(color.copy(alpha = 0.12f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize().padding(14.dp)) {
            val ring = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
            if (busy) drawArc(color, angle, 110f, false, style = ring) else drawCircle(color, style = ring)
            val c = center
            val r = size.minDimension * 0.2f
            val glyph = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
            drawArc(color, -60f, 300f, false, topLeft = Offset(c.x - r, c.y - r), size = Size(2 * r, 2 * r), style = glyph)
            drawLine(color, Offset(c.x, c.y - r * 1.2f), Offset(c.x, c.y - r * 0.1f), strokeWidth = 10.dp.toPx(), cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun ServerRow(s: Server, selected: Boolean, best: Boolean, onClick: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
    ) {
        Row(Modifier.padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    (if (best) "⚡ лучший · " else "") + s.protocol.uppercase(),
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            PingChip(s.pingMs)
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Меню") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Удалить") },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                        onClick = { menu = false; onDelete() },
                    )
                }
            }
        }
    }
}

@Composable
private fun PingChip(ms: Int) {
    val (text, color) = when {
        ms > 0 -> "$ms мс" to (if (ms <= 120) Green else if (ms <= 300) Amber else Red)
        ms < 0 -> "нет связи" to Red
        else -> "—" to Gray
    }
    Text(
        text, color = color, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.14f)).padding(horizontal = 10.dp, vertical = 5.dp),
    )
}

// ---------------------------------------------------------------- добавление ключа

@Composable
private fun AddKeyDialog(onDismiss: () -> Unit, onSubmit: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    val scan = rememberLauncherForActivityResult(ScanContract()) { res -> res.contents?.let { onSubmit(it) } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить ключ") },
        text = {
            Column {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 6,
                    placeholder = { Text("vless://… vmess://… trojan://… ss://… или ссылка подписки") },
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { clipboard.getText()?.text?.let { text = it } }) { Text("Вставить") }
                    OutlinedButton(onClick = {
                        scan.launch(
                            ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                                .setPrompt("Наведите камеру на QR-код").setBeepEnabled(false).setOrientationLocked(false)
                        )
                    }) { Text("QR-код") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSubmit(text) }, enabled = text.isNotBlank()) { Text("Добавить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

// ---------------------------------------------------------------- настройки

@Composable
private fun SettingsScreen(onBack: () -> Unit) {
    val subs by Store.subs.collectAsState()
    val failover by Settings.failover.collectAsState()
    val autoUpdate by Settings.autoUpdate.collectAsState()
    val scope = rememberCoroutineScope()
    var refreshing by remember { mutableStateOf(false) }
    val core = remember { try { Libv2ray.checkVersionX() } catch (e: Throwable) { "недоступно" } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 8.dp, 16.dp, 32.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад") }
                Text("Настройки", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            SwitchRow("Автопереключение при сбое", "Если сервер перестал отвечать (в режиме «Авто»), перейти на следующий по пингу", failover) { Settings.setFailover(it) }
            SwitchRow("Автообновление подписок", "Обновлять список серверов при запуске (раз в 6 часов)", autoUpdate) { Settings.setAutoUpdate(it) }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Подписки (${subs.size})", fontWeight = FontWeight.SemiBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                TextButton(
                    enabled = subs.isNotEmpty() && !refreshing,
                    onClick = { scope.launch { refreshing = true; Importer.refreshAll(); refreshing = false } },
                ) { Text(if (refreshing) "Обновляю…" else "Обновить все") }
            }
        }
        if (subs.isEmpty()) {
            item { Text("Подписок нет. Добавьте ссылку подписки на главном экране.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(subs, key = { it.id }) { sub ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(sub.title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            sub.info ?: "Серверов: ${Store.servers.value.count { it.subId == sub.id }}",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { scope.launch { Importer.refresh(sub) } }) { Icon(Icons.Default.Refresh, contentDescription = "Обновить") }
                    IconButton(onClick = { Store.removeSub(sub.id) }) { Icon(Icons.Default.Delete, contentDescription = "Удалить") }
                }
            }
        }
        item {
            Spacer(Modifier.height(24.dp))
            Text("Ядро: $core", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "Kill switch: Настройки Android → Сеть → VPN → KeyVPN → «Постоянная VPN» + «Блокировать соединения без VPN».",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
