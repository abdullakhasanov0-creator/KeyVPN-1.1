package com.keyvpn.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Green = Color(0xFF2ECC71)
val Amber = Color(0xFFF5A623)
val Red = Color(0xFFE5534B)
val Gray = Color(0xFF7D8BA1)

private val Dark = darkColorScheme(
    primary = Green, onPrimary = Color(0xFF06220F),
    background = Color(0xFF0E1420), onBackground = Color(0xFFE8EDF5),
    surface = Color(0xFF161E2E), onSurface = Color(0xFFE8EDF5),
    surfaceVariant = Color(0xFF1D2740), onSurfaceVariant = Color(0xFFA9B6CC),
    secondaryContainer = Color(0xFF1F3B2E), onSecondaryContainer = Color(0xFFBFF0D2),
)

private val Light = lightColorScheme(
    primary = Color(0xFF16A35A), onPrimary = Color.White,
    background = Color(0xFFF4F7FB), onBackground = Color(0xFF111827),
    surface = Color.White, onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFE8EEF7), onSurfaceVariant = Color(0xFF51607A),
    secondaryContainer = Color(0xFFD5F5E1), onSecondaryContainer = Color(0xFF0B3D20),
)

@Composable
fun KeyVpnTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
