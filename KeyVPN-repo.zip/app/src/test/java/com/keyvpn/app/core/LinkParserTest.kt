package com.keyvpn.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LinkParserTest {
    @Suppress("UNCHECKED_CAST")
    private fun Map<String, Any?>.m(k: String) = this[k] as Map<String, Any?>

    @Suppress("UNCHECKED_CAST")
    private fun Map<String, Any?>.l(k: String) = this[k] as List<Any?>

    @Test
    fun vlessReality() {
        val p = LinkParser.parseLink(
            "vless://11111111-2222-3333-4444-555555555555@example.com:443?type=tcp&security=reality&sni=www.microsoft.com" +
                "&fp=chrome&pbk=PUBKEY&sid=ab12&spx=%2F&flow=xtls-rprx-vision&encryption=none#%F0%9F%87%A9%F0%9F%87%AA%20Berlin"
        )!!
        assertEquals("vless", p.protocol)
        assertEquals("example.com", p.host)
        assertEquals(443, p.port)
        assertTrue(p.name.endsWith("Berlin"))
        val user = (p.outbound.m("settings").l("vnext")[0] as Map<String, Any?>).l("users")[0] as Map<String, Any?>
        assertEquals("xtls-rprx-vision", user["flow"])
        val st = p.outbound.m("streamSettings")
        assertEquals("reality", st["security"])
        assertEquals("PUBKEY", st.m("realitySettings")["publicKey"])
        assertEquals("www.microsoft.com", st.m("realitySettings")["serverName"])
    }

    @Test
    fun vlessWsTlsDefaultsHostFromSni() {
        val p = LinkParser.parseLink("vless://id@1.2.3.4:8443?type=ws&security=tls&sni=cdn.site.com&path=%2Fws#x")!!
        val st = p.outbound.m("streamSettings")
        assertEquals("ws", st["network"])
        assertEquals("cdn.site.com", st.m("wsSettings").m("headers")["Host"])
        assertEquals("/ws", st.m("wsSettings")["path"])
        assertEquals("cdn.site.com", st.m("tlsSettings")["serverName"])
    }

    @Test
    fun vmessJson() {
        val json = """{"v":"2","ps":"My VM","add":"vm.example.com","port":"443","id":"uuid-1","aid":"0","scy":"auto","net":"ws","type":"none","host":"vm.example.com","path":"/p","tls":"tls","sni":""}"""
        val b64 = java.util.Base64.getEncoder().encodeToString(json.toByteArray())
        val p = LinkParser.parseLink("vmess://$b64")!!
        assertEquals("My VM", p.name)
        assertEquals("vmess", p.protocol)
        assertEquals(443, p.port)
        assertEquals("tls", p.outbound.m("streamSettings")["security"])
        assertEquals("vm.example.com", p.outbound.m("streamSettings").m("tlsSettings")["serverName"])
    }

    @Test
    fun trojanDefaultsToTls() {
        val p = LinkParser.parseLink("trojan://pa%24s@tr.example.com:443?type=grpc&serviceName=svc#T")!!
        assertEquals("tls", p.outbound.m("streamSettings")["security"])
        assertEquals("svc", p.outbound.m("streamSettings").m("grpcSettings")["serviceName"])
        assertEquals("pa\$s", (p.outbound.m("settings").l("servers")[0] as Map<String, Any?>)["password"])
    }

    @Test
    fun shadowsocksBothForms() {
        val ui = java.util.Base64.getEncoder().encodeToString("aes-256-gcm:secret".toByteArray())
        val a = LinkParser.parseLink("ss://$ui@ss.example.com:8388#SS1")!!
        assertEquals("SS1", a.name)
        assertEquals(8388, a.port)
        val all = java.util.Base64.getEncoder().encodeToString("chacha20-ietf-poly1305:pw@9.9.9.9:1234".toByteArray())
        val b = LinkParser.parseLink("ss://$all#SS2")!!
        assertEquals("9.9.9.9", b.host)
        assertEquals("chacha20-ietf-poly1305", (b.outbound.m("settings").l("servers")[0] as Map<String, Any?>)["method"])
    }

    @Test
    fun ipv6Host() {
        val p = LinkParser.parseLink("vless://id@[2001:db8::1]:443?security=tls#v6")!!
        assertEquals("2001:db8::1", p.host)
    }

    @Test
    fun subscriptionBlobAndPlainList() {
        val text = "vless://a@h1.com:443?security=tls#A\ntrojan://p@h2.com:443#B\nnonsense"
        assertEquals(2, LinkParser.parseAny(text).size)
        val blob = java.util.Base64.getEncoder().encodeToString(text.toByteArray())
        assertEquals(2, LinkParser.parseAny(blob).size)
        assertEquals(0, LinkParser.parseAny("hello world").size)
    }

    @Test
    fun garbageDoesNotCrash() {
        assertNull(LinkParser.parseLink("vless://"))
        assertNull(LinkParser.parseLink("vmess://!!!"))
        assertNull(LinkParser.parseLink("ss://@@"))
    }

    @Test
    fun subscriptionUrls() {
        assertEquals("https://sub.example.com/abc", Links.subscriptionUrl("happ://add/https://sub.example.com/abc"))
        assertEquals("https://sub.example.com/abc?x=1", Links.subscriptionUrl("v2rayng://install-config?url=https%3A%2F%2Fsub.example.com%2Fabc%3Fx%3D1&name=q"))
        assertEquals("https://a.b/c", Links.subscriptionUrl(" https://a.b/c "))
        assertNull(Links.subscriptionUrl("vless://a@b:1"))
    }

    @Test
    fun configContainsTunAndProxy() {
        val p = LinkParser.parseLink("vless://id@h.com:443?security=tls#x")!!
        val cfg = Json.parseObject(ConfigBuilder.full(p.outbound))
        assertEquals("tun", (cfg.l("inbounds")[0] as Map<String, Any?>)["protocol"])
        assertEquals("proxy", (cfg.l("outbounds")[0] as Map<String, Any?>)["tag"])
        assertNotNull(Json.parseObject(ConfigBuilder.probe(p.outbound)))
    }

    @Test
    fun userInfoFormatting() {
        val s = Fmt.userInfo("upload=0; download=1073741824; total=10737418240; expire=1798675200")!!
        assertTrue(s.startsWith("Осталось 9.0 ГБ"))
        assertNull(Fmt.userInfo(null))
    }

    @Test
    fun jsonRoundTrip() {
        val src = mapOf("a" to listOf(1, 2.5, "x\"y\n"), "b" to mapOf("c" to true, "d" to null))
        val back = Json.parse(Json.stringify(src)) as Map<*, *>
        assertEquals(listOf(1L, 2.5, "x\"y\n"), back["a"])
    }
}
